# tetringUSB-OPENWRT
this tools help you to tethering-usb android phone without touching it directly (remote via ADB shell and BASH) 

#script yg berfungsi mengontrol android phone sabagai modem, 

script ini hanya shortcut singkat dalam logika dasar BASH, mohon nonton video dibawah , agar berjalan normal.

HOW TO USE ?

you can watch my tutorial in my youtube video

link : https://youtu.be/SP7841kmiCI 

this script need to :

1. adb, android debug bridge (opkg install adb)
2. android phone (It is suggested which android is root)
